﻿namespace CampRating
{
    public static class GlobalConstants
    {
        public const string AdminRole = "Admin";
        public const string UserRole = "User";
    }
}
