﻿namespace CampRating.Data.Models
{
    public class Review
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();

        public string UserId { get; set; }

        public virtual User User { get; set; }

        public string CampId { get; set; }

        public virtual Camp Camp { get; set; }

        public double Rating { get; set; }

        public string ReviewText { get; set; }
    }
}
