﻿namespace CampRating.Controllers
{
    using Microsoft.AspNetCore.Mvc;
    using ViewModels.Camps;
    using Services.Contracts;
    using Microsoft.AspNetCore.Authorization;
    using CampRating.Data.Models;

    public class CampsController : Controller
    {
        private readonly ICampService CampsService;

        public CampsController(ICampService CampService)
        {
            this.CampsService = CampService;
        }

        // GET: Camps
        public async Task<IActionResult> Index(IndexCampsViewModel Camps)
        {
            Camps = await CampsService.GetCampsAsync(Camps);
            return View(Camps);
        }

        // GET: Camps/Details/5
        public async Task<IActionResult> Details(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var Camp = await CampsService.GetCampDetailsByIdAsync(id);
            if (Camp == null)
            {
                return NotFound();
            }

            return View(Camp);
        }

        [Authorize(Roles = GlobalConstants.AdminRole)]
        // GET: Camps/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Camps/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [Authorize(Roles = GlobalConstants.AdminRole)]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(CreateCampViewModel Camp)
        {
            if (ModelState.IsValid)
            {
                await CampsService.CreateCampAsync(Camp);
                return RedirectToAction(nameof(Index));
            }
            return View(Camp);
        }

        // GET: Camps/Edit/5
        [Authorize(Roles = GlobalConstants.AdminRole)]
        public async Task<IActionResult> Edit(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var Camp = await CampsService.GetCampToEditAsync(id);
            if (Camp == null)
            {
                return NotFound();
            }
            return View(Camp);
        }

        // POST: Camps/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [Authorize(Roles = GlobalConstants.AdminRole)]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(EditCampViewModel editCamp)
        {
            if (ModelState.IsValid)
            {
                await CampsService.UpdateCampAsync(editCamp);
                return RedirectToAction(nameof(Index));
            }
            return View(editCamp);
        }

        // GET: Camps/Delete/5
        [Authorize(Roles = GlobalConstants.AdminRole)]
        public async Task<IActionResult> Delete(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var Camp = await CampsService.GetCampToDeleteByIdAsync(id);
            if (Camp == null)
            {
                return NotFound();
            }

            return View(Camp);
        }

        // POST: Camps/Delete/5
        [Authorize(Roles = GlobalConstants.AdminRole)]
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(string id)
        {
            var Camp = await CampsService.GetCampToDeleteByIdAsync(id); 
            if (Camp != null)
            {
                await CampsService.DeleteCampByIdAsync(id);
            }

            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Seed()
        {
            IFormFile file = ConvertToIFormFile("C:\\Users\\Alishov\\Desktop\\CampRating\\CampRating\\wwwroot\\images\\defaultCamp.jpg");
            for (int i = 0; i < 40; i++)
            {
                CreateCampViewModel model = new CreateCampViewModel() 
                {
                    Name=$"Camp {i}",
                    Description=$"Description for Camp {i}",
                    ImageFile=file
                };
                await CampsService.CreateCampAsync(model);
            }
            return RedirectToAction(nameof(Index));
        }

        public IFormFile ConvertToIFormFile(string filePath)
        {
            var fileInfo = new FileInfo(filePath);
            var fileStream = new FileStream(filePath, FileMode.Open);

            IFormFile formFile = new FormFile(fileStream, 0, fileInfo.Length, fileInfo.Name, fileInfo.Name)
            {
                Headers = new HeaderDictionary(),
                ContentType = "application/octet-stream"
            };

            return formFile;
        }
    }
}
