using CampRating.Data;
using CampRating.Services.Contracts;
using CampRating.ViewModels;
using CampRating.ViewModels.Home;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace CampRating.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly ICampService CampService;
        private readonly ApplicationDbContext context;

        public HomeController(ILogger<HomeController> logger, ICampService CampService, ApplicationDbContext context)
        {
            _logger = logger;
            this.CampService = CampService;
            this.context = context;
        }

        public async Task<IActionResult> Index(IndexHomeViewModel model)
        {
            model.UsersCount = context.Users.Count();
            model.CampsCount = context.Camps.Count();
            model.ReviewsCount = context.Reviews.Count();
            return View(model);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
