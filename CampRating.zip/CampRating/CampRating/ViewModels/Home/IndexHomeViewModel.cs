﻿using CampRating.ViewModels.Camps;

namespace CampRating.ViewModels.Home
{
    public class IndexHomeViewModel
    {
        public int UsersCount { get; set; }
        public int CampsCount { get; set; }
        public int ReviewsCount { get; set; }
    }
}
