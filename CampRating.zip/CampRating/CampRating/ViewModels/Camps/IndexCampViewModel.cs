﻿using System.ComponentModel.DataAnnotations;

namespace CampRating.ViewModels.Camps
{
    public class IndexCampViewModel
    {
        public string Id { get; set; }

        public string Name { get; set; }

        public string AverageRating { get; set; }
        public int Longitude { get; set; }
        public int Latitude { get; set; }


        [Display(Name = "Picture")]
        public string? Image { get; set; }
    }
}
