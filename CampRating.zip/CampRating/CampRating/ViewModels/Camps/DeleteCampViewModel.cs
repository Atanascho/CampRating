﻿namespace CampRating.ViewModels.Camps
{
    public class DeleteCampViewModel
    {
        public  string Id { get; set; }

        public string Name { get; set; }

        public string AverageRating { get; set; }
    }
}
