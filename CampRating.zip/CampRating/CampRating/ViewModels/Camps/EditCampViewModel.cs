﻿using System.ComponentModel.DataAnnotations;

namespace CampRating.ViewModels.Camps
{
    public class EditCampViewModel
    {
        public string Id { get; set; }


        [Required]
        [MaxLength(64)]
        public string Name { get; set; }

        [MaxLength(255)]
        public string Description { get; set; }
        public int Longitude { get; set; }
        public int Latitude { get; set; }

        public IFormFile? ImageFile { get; set; }
    }
}
