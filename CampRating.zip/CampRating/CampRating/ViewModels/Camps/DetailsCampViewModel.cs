﻿namespace CampRating.ViewModels.Camps
{
    public class DetailsCampViewModel
    {
        public string Id { get; set; }

        public string Name { get; set; }

        public string? Image { get; set; }

        public string Description { get; set; }

        public string AverageRating { get; set; }
        public int Longitude { get; set; }
        public int Latitude { get; set; }

        public ICollection<ReviewCampViewModel> Reviews { get; set; } = new HashSet<ReviewCampViewModel>();
    }
}
