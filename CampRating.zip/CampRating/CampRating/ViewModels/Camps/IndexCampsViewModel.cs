﻿using CampRating.ViewModels.Users;

namespace CampRating.ViewModels.Camps
{
    public class IndexCampsViewModel : PagingViewModel
    {
        public IndexCampsViewModel() : base(10)
        {

        }
        public IndexCampsViewModel(int elementsCount, int itemsPerPage = 5, string action = "Index") : base(elementsCount, itemsPerPage, action)
        {
        }

        public string FilterByName { get; set; }

        public bool IsAsc { get; set; } = true;

        public ICollection<IndexCampViewModel> Camps { get; set; } = new List<IndexCampViewModel>();
    }
}
