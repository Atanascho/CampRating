﻿namespace CampRating.ViewModels.Camps
{
    public class ReviewCampViewModel
    {
        public string UserLasName { get; set; }
        public double Rating { get; set; }

        public string ReviewText { get; set; }
    }
}
