﻿namespace CampRating.ViewModels.Reviews
{
    public class IndexReviewViewModel
    {
        public string UserId { get; set; }

        public string ReviewId { get; set; }

        public string CampName { get; set; }

        public double Rating { get; set; }

        public string ReviewText { get; set; }
    }
}
