﻿namespace CampRating.ViewModels.Reviews
{
    public class CreateReviewViewModel
    {
        public string CampId { get; set; }

        public  double Rating { get; set; }

        public string ReviewText { get; set; }
    }
}
