﻿using CampRating.Data;
using CampRating.Data.Models;
using CampRating.Services.Contracts;
using CampRating.ViewModels.Camps;
using CampRating.ViewModels.Reviews;
using Microsoft.EntityFrameworkCore;
using System;

namespace CampRating.Services
{
    public class ReviewsService : IReviewsService
    {
        private readonly ApplicationDbContext context;

        public ReviewsService(ApplicationDbContext context)
        {
            this.context = context;
        }
        public async Task<string> CreateReviewAsync(CreateReviewViewModel model, string userId)
        {
            Review review = new Review()
            {
                Rating = Math.Round(model.Rating,2),
                UserId = userId,
                ReviewText = model.ReviewText,
                CampId = model.CampId
            };

            await context.Reviews.AddAsync(review);
            await context.SaveChangesAsync();

            return review.Id;
        }

        public async Task<IndexReviewsUserViewModel> GetAllReviewsAsync(IndexReviewsUserViewModel model)
        {
            if (model == null)
            {
                model = new IndexReviewsUserViewModel(10);
            }
            IQueryable<Review> reviewsData = context.Reviews;

            model.ElementsCount = await reviewsData.CountAsync();

            model.UserReviews = await reviewsData
              .Skip((model.Page - 1) * model.ItemsPerPage)
              .Take(model.ItemsPerPage)
              .Select(x => new IndexReviewViewModel()
              {
                  ReviewId = x.Id,
                  CampName = x.Camp.Name,
                  Rating = Math.Round(x.Rating,2),
                  ReviewText = x.ReviewText
              })
              .ToListAsync();

            return model;
        }

        public async Task<IndexReviewsUserViewModel> GetUserReviewsAsync(IndexReviewsUserViewModel model, string userId)
        {
            if (model == null)
            {
                model = new IndexReviewsUserViewModel(10);
            }
            IQueryable<Review> reviewsData = context.Reviews.Where(x => x.UserId == userId);

            model.ElementsCount = await reviewsData.CountAsync();

            model.UserReviews = await reviewsData
              .Skip((model.Page - 1) * model.ItemsPerPage)
              .Take(model.ItemsPerPage)
              .Select(x => new IndexReviewViewModel()
              {
                  ReviewId = x.Id,
                  CampName = x.Camp.Name,
                  UserId = userId,
                  Rating = Math.Round(x.Rating,2),
                  ReviewText = x.ReviewText
              })
              .ToListAsync();

            return model;
        }

        public async Task SeedReviewsAsync()
        {
            List<Camp> Camps = context.Camps.Where(x => !x.Reviews.Any()).ToList();
            foreach (var Camp in Camps)
            {
                for (int i = 0; i < 3; i++)
                {
                    double rating = GenerateRandomNumber();
                    User user = context.Users.FirstOrDefault();
                    Camp.Reviews.Add(new Review()
                    {
                        Rating = rating,
                        ReviewText = $"Seed review {i} - {rating}",
                        User = user
                    });
                }
            }

            context.Camps.UpdateRange(Camps);
            await context.SaveChangesAsync();

        }

        public double GenerateRandomNumber(double minValue = 0.0, double maxValue = 10.0)
        {
            Random random = new Random();
            return random.NextDouble() * (maxValue - minValue) + minValue;
        }
    }
}
