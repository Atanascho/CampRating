﻿using CampRating.ViewModels.Camps;

namespace CampRating.Services.Contracts
{
    public interface ICampService
    {
        public Task<IndexCampViewModel> GetWorstCampAsync();
        public Task<IndexCampViewModel> GetBestCampAsync();
        public Task DeleteCampByIdAsync(string CampId);

        public Task<DeleteCampViewModel> GetCampToDeleteByIdAsync(string CampId);

        public Task<DetailsCampViewModel> GetCampDetailsByIdAsync(string CampId);

        public Task<string> CreateCampAsync(CreateCampViewModel model);

        public Task<IndexCampsViewModel> GetCampsAsync(IndexCampsViewModel model);

        public Task<string> UpdateCampAsync(EditCampViewModel model);

        public Task<EditCampViewModel> GetCampToEditAsync(string CampId);
    }
}
